//
// Created by vov4i on 29-Jun-18.
//
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "mtm_array.h"
